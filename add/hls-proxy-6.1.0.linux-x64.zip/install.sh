#!/bin/sh
# Setup HLS-Proxy
#

if [ ! -f hls-proxy ]; then
    echo "You should run install.sh from a directory of hls-proxy."
    echo "Interrupted"
    exit
fi

install1 () {

    # Add to autostart
    sudo -E bash -c 'cat >$AUTOSTART_FILE <<EOL
[Unit]
Description=HLS proxy for IPTV
Wants=network-online.target
After=network-online.target

[Service]
User=$HLSUSER
ExecStart=$EXECUTABLE
ExecReload=/bin/kill -HUP \$MAINPID
ExecStop=/bin/kill -HUP \$MAINPID
KillMode=process
Restart=always

[Install]
WantedBy=multi-user.target
Alias=hls-proxy.service
EOL'

# Allow binding ports below 1024
#if [ -f "$(which setcap)" ]; then
#    sudo setcap 'cap_net_bind_service=+ep' $EXECUTABLE
#fi
# Nice persistent replacement for setcap

    sudo sysctl -q net.ipv4.ip_unprivileged_port_start=80

if [ "$(cat /etc/sysctl.conf|grep net.ipv4.ip_unprivileged_port_start)" = "" ]; then
    sudo -E bash -c 'echo net.ipv4.ip_unprivileged_port_start=80 >> /etc/sysctl.conf'
    echo Port 80 permitted at /etc/sysctl.conf
fi

    chmod 755 ./hls-proxy
    sudo $SYSTEMCTL enable hls-proxy
    echo Added to autostart

}

uninstall1 () {

    sudo $SYSTEMCTL disable hls-proxy
    sudo $SYSTEMCTL stop hls-proxy

    if [ -f $AUTOSTART_FILE ]; then
        sudo rm $AUTOSTART_FILE
    fi

    echo HLS stopped and removed from autostart
}

start1 () {

    sudo $SYSTEMCTL restart hls-proxy
    echo HLS-Proxy started

}

status () {

    sudo $SYSTEMCTL status hls-proxy

}

reloaddaemon () {

    sudo $SYSTEMCTL daemon-reload

}

help () {

    echo
    echo Usage:
    echo      ./install.sh [options]
    echo
    echo Options:
    echo      u - uninstall \(stop and remove from autostart\)
    echo      s - status \(and last log messages\)
    echo      h - this help

}

EXECUTABLE=$(pwd)/hls-proxy
ICON=$(pwd)/favicon.png
HLSUSER=$USER

# Store file at services dir
AUTOSTART_FILE="/lib/systemd/system/hls-proxy.service"


# Detect chroot enviroment
if [ "$(stat -c %d:%i /)" != "$(sudo stat -c %d:%i /proc/1/root/.)" ]; then
    echo "We are under chroot! Use install_chroot.sh"
    exit 0    
fi

SYSTEMCTL=systemctl

export AUTOSTART_FILE
export EXECUTABLE
export HLSUSER
export SYSTEMCTL

if [ "$1" = "U" -o "$1" = "u" ]; then
    uninstall1
    reloaddaemon

elif [ "$1" = "S" -o "$1" = "s" ]; then
    status
elif [ "$1" = "H" -o "$1" = "h" ]; then
    help
else
    install1
    reloaddaemon
    start1
    help
fi



unset EXECUTABLE
unset AUTOSTART_FILE
unset HLSUSER
unset SYSTEMCTL
